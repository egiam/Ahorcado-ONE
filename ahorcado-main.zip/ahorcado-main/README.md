# ahorcado
Un ahorcado hecho con JS, HTML y css
Proyecto creado en este tutorial: https://youtu.be/I3S6B2p-VHg

<img width="394" alt="Screen Shot 2022-03-01 at 20 28 52" src="https://user-images.githubusercontent.com/26985597/156266259-2d5f1f1c-252c-46a9-aa7b-665ac958e37e.png">
